GLYPHISH PRO v3 - 400 ICONS
Created by Joseph Wain, 2010 – 2011
Web: http://glyphish.com or http://penandthink.com
Twitter: @glyphish or @jpwain

----------

Thanks for supporting Glyphish!

LICENSE:
You're free to use these icons for commercial and non-commercial purposes, for yourself, your company and your clients, and to edit, remix and otherwise modify them without attribution. You may not sell or redistribute the icons themselves as icons. Additionally, you may not use them in a way that encourages downstream distribution -- this means no templates or skins or theme kits or similar uses. (The person using the theme or template might not know where the icons came from and thus wouldn't be following the license.) The icons may not be used in any form of "app builder" tools of any kind.

ATTRIBUTION:
None required for use by you, your company, your clients. But if you'd like to spread the word by linking to Glyphish from your website, blogpost, Twitter or wherever, your kind words are much appreciated.

QUESTIONS, COMMENTS:
Contact me via glyphish.com.